package local.phonemirror.tv;

import android.graphics.Matrix;
import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONObject;
import org.webrtc.*;
import local.phonemirror.rtc.RtcFrameOrientation;

/** QA only: verify CPU and GPU pixel orientation, plane order, timestamps and buffer ownership. */
final class OrientationChecks {
    static JSONObject run(EglBase.Context shared)throws Exception {
        int width=80,height=128;
        JavaI420Buffer pixels=JavaI420Buffer.allocate(width,height);
        for(int y=0;y<height;y++)for(int x=0;x<width;x++)pixels.getDataY().put(y*pixels.getStrideY()+x,(byte)(32+(x/10)*12+(y/16)*7));
        for(int y=0;y<height/2;y++)for(int x=0;x<width/2;x++){
            pixels.getDataU().put(y*pixels.getStrideU()+x,(byte)(55+x+y));
            pixels.getDataV().put(y*pixels.getStrideV()+x,(byte)(195-x-y));
        }
        VideoFrame frame=new VideoFrame(pixels,0,123456789L);
        try {
            for(int rotation:new int[]{0,90,180,270}) {
                pixels.retain();
                VideoFrame input=new VideoFrame(pixels,rotation,frame.getTimestampNs());
                VideoFrame output=RtcFrameOrientation.landscapeBuffer(input);
                try { check(input,output,0); } finally { output.release();input.release(); }
            }
        } finally { frame.release(); }

        AtomicInteger destroyed=new AtomicInteger();
        JavaI420Buffer owned=JavaI420Buffer.wrap(8,4,ByteBuffer.allocateDirect(32),8,
                ByteBuffer.allocateDirect(8),4,ByteBuffer.allocateDirect(8),4,destroyed::incrementAndGet);
        VideoFrame landscape=new VideoFrame(owned,180,42),retained=RtcFrameOrientation.landscapeBuffer(landscape);
        landscape.release();
        if(destroyed.get()!=0)throw new AssertionError("Frame released too early");
        retained.release();
        if(destroyed.get()!=1)throw new AssertionError("Frame ownership leaked");

        SurfaceTextureHelper helper=SurfaceTextureHelper.create("QA-orientation-texture",shared);
        if(helper==null)throw new IllegalStateException("EGL unavailable");
        try {
            ThreadUtils.invokeAtFrontUninterruptibly(helper.getHandler(),()->{
                int[] texture={0};GLES20.glGenTextures(1,texture,0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture[0]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
                ByteBuffer rgba=ByteBuffer.allocateDirect(width*height*4);
                for(int y=0;y<height;y++)for(int x=0;x<width;x++)rgba.put((byte)(32+x)).put((byte)(40+y)).put((byte)(210-x)).put((byte)255);
                rgba.flip();GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D,0,GLES20.GL_RGBA,width,height,0,GLES20.GL_RGBA,GLES20.GL_UNSIGNED_BYTE,rgba);
                YuvConverter converter=new YuvConverter();
                VideoFrame input=new VideoFrame(new TextureBufferImpl(width,height,VideoFrame.TextureBuffer.Type.RGB,
                        texture[0],new Matrix(),helper.getHandler(),converter,null),0,987654321L);
                VideoFrame output=RtcFrameOrientation.landscapeBuffer(input);
                try { check(input,output,4); }
                finally { output.release();input.release();converter.release();GLES20.glDeleteTextures(1,texture,0); }
            });
        } finally { helper.dispose(); }
        return new JSONObject().put("cpuPixelRotation",true).put("gpuPixelRotation",true)
                .put("chromaPlanes",true).put("allInputRotations",true).put("timestamps",true).put("referenceOwnership",true);
    }

    private static void check(VideoFrame input,VideoFrame output,int tolerance) {
        if(output.getBuffer().getWidth()!=input.getBuffer().getHeight()
                ||output.getBuffer().getHeight()!=input.getBuffer().getWidth()
                ||output.getRotation()!=(input.getRotation()+270)%360
                ||output.getTimestampNs()!=input.getTimestampNs())throw new AssertionError("Frame geometry or timestamp changed");
        VideoFrame.I420Buffer before=input.getBuffer().toI420(),after=output.getBuffer().toI420();
        try {
            checkPlane(before.getDataY(),before.getStrideY(),after.getDataY(),after.getStrideY(),before.getWidth(),before.getHeight(),tolerance);
            checkPlane(before.getDataU(),before.getStrideU(),after.getDataU(),after.getStrideU(),before.getWidth()/2,before.getHeight()/2,tolerance);
            checkPlane(before.getDataV(),before.getStrideV(),after.getDataV(),after.getStrideV(),before.getWidth()/2,before.getHeight()/2,tolerance);
        } finally { before.release();after.release(); }
    }
    private static void checkPlane(ByteBuffer before,int stride,ByteBuffer after,int outStride,int width,int height,int tolerance) {
        for(int y=2;y<width-2;y+=7)for(int x=2;x<height-2;x+=7){
            int expected=before.get((height-1-x)*stride+y)&255,actual=after.get(y*outStride+x)&255;
            if(Math.abs(expected-actual)>tolerance)throw new AssertionError("Rotated pixel or color plane mismatch: "+expected+" != "+actual);
        }
    }
}
