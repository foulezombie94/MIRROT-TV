package local.phonemirror.tv;

import android.app.Activity;
import android.os.*;
import android.widget.FrameLayout;
import org.webrtc.*;
import org.webrtc.audio.JavaAudioDeviceModule;
import org.json.*;
import local.phonemirror.rtc.RtcPeer;
import local.phonemirror.rtc.RtcFrameOrientation;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.LockSupport;
import java.io.*;

/** QA ONLY. Real native WebRTC encode/RTP/decode/render, synthetic video/PCM, same emulator. */
public final class RtcProbeActivity extends Activity {
 private RtcReceiver receiver;
 private volatile boolean stopped;
 private final Map<Integer,Long> sent=new ConcurrentHashMap<>();
 private final List<Long> latency=Collections.synchronizedList(new ArrayList<>());
 private final List<JSONObject> samples=new ArrayList<>();
 private final List<JSONObject> decodeTrace=Collections.synchronizedList(new ArrayList<>());
 private final List<JSONObject> sourceTrace=new ArrayList<>(),events=new ArrayList<>();
 private long lastDecodedNs;
 private boolean rotate,restart,stableOrientation,repeatRotation,initialPortrait;
 private int requestedFrames,requestedFps;
 private long startedNs,firstDecodedNs;
 private volatile int decoded;
 private final String id=UUID.randomUUID().toString();
 @Override public void onCreate(Bundle b){super.onCreate(b);rotate=getIntent().getBooleanExtra("rotate",true);restart=getIntent().getBooleanExtra("restart",true);stableOrientation=getIntent().getBooleanExtra("stable",true);repeatRotation=getIntent().getBooleanExtra("repeat",false);initialPortrait=getIntent().getBooleanExtra("portrait",false);requestedFps=getIntent().getIntExtra("fps",30)==60?60:30;requestedFrames=Math.max(600,Math.min(3600,getIntent().getIntExtra("frames",900)));getWindow().addFlags(128);FrameLayout root=new FrameLayout(this);setContentView(root);receiver=new RtcReceiver(this,root,id,this::observed);new Thread(this::run,"RTC-probe").start();}
 private void observed(VideoFrame frame){long entered=System.nanoTime();VideoFrame.I420Buffer image=frame.getBuffer().toI420();try{int code=0;ByteBuffer y=image.getDataY();int stride=image.getStrideY();for(int bit=0;bit<16;bit++){int x=(2*bit+1)*frame.getRotatedWidth()/32,dy=Math.min(frame.getRotatedHeight()-1,20);int bx=x,by=dy;switch(frame.getRotation()){case 90:bx=dy;by=image.getHeight()-1-x;break;case 180:bx=image.getWidth()-1-x;by=image.getHeight()-1-dy;break;case 270:bx=image.getWidth()-1-dy;by=x;break;default:break;}int level=y.get(by*stride+bx)&255;if(level>120)code|=1<<bit;}Long time=sent.get(code);if(time!=null){long now=System.nanoTime();if(firstDecodedNs==0)firstDecodedNs=now;latency.add((now-time)/1_000_000);decoded++;try{decodeTrace.add(new JSONObject().put("code",code).put("elapsedMs",(entered-startedNs)/1e6).put("gapMs",lastDecodedNs==0?0:(entered-lastDecodedNs)/1e6).put("latencyMs",(now-time)/1e6).put("width",image.getWidth()).put("height",image.getHeight()).put("rotation",frame.getRotation()).put("displayWidth",frame.getRotatedWidth()).put("displayHeight",frame.getRotatedHeight()).put("inspectionMs",(now-entered)/1e6));}catch(JSONException ignored){}lastDecodedNs=entered;}}finally{image.release();}}
 private void event(String name,int frame)throws JSONException{JSONObject value=new JSONObject().put("name",name).put("frame",frame).put("elapsedMs",(System.nanoTime()-startedNs)/1e6);events.add(value);android.util.Log.i("RtcProbe",value.toString());}
 private void run(){EglBase egl=null;RtcPeer sender=null;JavaAudioDeviceModule audio=null;VideoSource source=null;VideoTrack track=null;AudioSource as=null;org.webrtc.AudioTrack at=null;try{
  egl=EglBase.create();JSONObject orientationChecks=OrientationChecks.run(egl.getEglBaseContext());final long[] audioSample={0};audio=JavaAudioDeviceModule.builder(this).setInputSampleRate(48000).setUseStereoInput(true).setUseHardwareNoiseSuppressor(false).setUseHardwareAcousticEchoCanceler(false).setEnableVolumeLogger(false).setAudioBufferCallback((buffer,format,channels,rate,read,time)->{long due=System.nanoTime()+10_000_000;buffer.clear();buffer.order(ByteOrder.LITTLE_ENDIAN);while(buffer.remaining()>=4){short value=(short)(5000*Math.sin(audioSample[0]++*2*Math.PI*440/48000));buffer.putShort(value);buffer.putShort(value);}LockSupport.parkNanos(Math.max(0,due-System.nanoTime()));return due-10_000_000;}).createAudioDeviceModule();audio.setAudioRecordEnabled(false);audio.setSpeakerMute(true);
  sender=new RtcPeer(this,egl.getEglBaseContext(),audio,new RtcPeer.Listener(){});source=sender.factory().createVideoSource(true);source.getCapturerObserver().onCapturerStarted(true);track=sender.factory().createVideoTrack("probe-video",source);sender.addVideo(track,requestedFps,4_000_000);as=sender.factory().createAudioSource(new MediaConstraints());at=sender.factory().createAudioTrack("probe-audio",as);sender.addAudio(at);
  startedNs=System.nanoTime();String offer=sender.offer(false);JSONObject response=receiver.answer(new JSONObject().put("id",id).put("sdp",offer));boolean orientationRtp=offer.contains("urn:3gpp:video-orientation")&&response.getString("sdp").contains("urn:3gpp:video-orientation");sender.acceptAnswer(response.getString("sdp"));sender.addIce(response.optJSONArray("candidates"));long next=System.nanoTime(),lastStats=0;boolean restarted=false;int width=initialPortrait?720:1280,height=initialPortrait?1280:720;
  for(int frame=1;frame<=requestedFrames&&!stopped;frame++){
   long now=System.nanoTime();if(now<next)LockSupport.parkNanos(next-now);next+=1_000_000_000L/requestedFps;
   if(frame==300&&restart){event("ice-start",frame);response=receiver.answer(new JSONObject().put("id",id).put("sdp",sender.offer(true)));sender.acceptAnswer(response.getString("sdp"));sender.addIce(response.optJSONArray("candidates"));restarted=true;event("ice-complete",frame);}
   if(frame==1)source.adaptOutputFormat(width,height,requestedFps);
   if(rotate&&(frame==450||(repeatRotation&&frame>450&&frame%150==0))){event("rotation",frame);int previous=width;width=height;height=previous;source.adaptOutputFormat(width,height,requestedFps);}
   long buildStarted=System.nanoTime();
   JavaI420Buffer buffer=JavaI420Buffer.allocate(width,height);byte[] luma=new byte[width];for(int bit=0;bit<16;bit++)Arrays.fill(luma,bit*width/16,(bit+1)*width/16,(byte)((frame&(1<<bit))==0?32:224));ByteBuffer y=buffer.getDataY();for(int row=0;row<height;row++){y.position(row*buffer.getStrideY());y.put(luma);}for(ByteBuffer plane:new ByteBuffer[]{buffer.getDataU(),buffer.getDataV()})while(plane.hasRemaining())plane.put((byte)128);
   long captured=System.nanoTime();VideoFrame video=new VideoFrame(buffer,0,captured);sent.put(frame,captured);if(stableOrientation){VideoFrame stable=RtcFrameOrientation.landscapeBuffer(video);try{source.getCapturerObserver().onFrameCaptured(stable);}finally{stable.release();}}else source.getCapturerObserver().onFrameCaptured(video);video.release();sourceTrace.add(new JSONObject().put("frame",frame).put("elapsedMs",(captured-startedNs)/1e6).put("buildMs",(captured-buildStarted)/1e6).put("width",width).put("height",height));
   response=receiver.exchange(new JSONObject().put("id",id).put("candidates",sender.ice()));sender.addIce(response.optJSONArray("candidates"));
   if(SystemClock.elapsedRealtime()-lastStats>=1000){lastStats=SystemClock.elapsedRealtime();sender.collectStats();samples.add(new JSONObject().put("elapsedMs",(System.nanoTime()-startedNs)/1_000_000).put("receiver",response.getJSONObject("status")).put("sender",sender.metrics()));}
  }
  Thread.sleep(500);response=receiver.exchange(new JSONObject().put("id",id).put("candidates",sender.ice()));Thread.sleep(200);
  ArrayList<Long> sorted=new ArrayList<>(latency);Collections.sort(sorted);JSONObject result=new JSONObject().put("decodedBarcodeFrames",decoded).put("sourceFrames",requestedFrames).put("fps",requestedFps).put("stableOrientation",stableOrientation).put("initialPortrait",initialPortrait).put("orientationChecks",orientationChecks).put("orientationRtpNegotiated",orientationRtp).put("iceRestartAttempted",restarted).put("rotationAttempted",rotate).put("samples",new JSONArray(samples)).put("events",new JSONArray(events)).put("sourceTrace",new JSONArray(sourceTrace)).put("decodeTrace",new JSONArray(decodeTrace)).put("finalReceiver",receiver.status()).put("firstDecodedMs",firstDecodedNs==0?-1:(firstDecodedNs-startedNs)/1_000_000).put("p50DecodeLatencyMs",sorted.isEmpty()?-1:sorted.get(sorted.size()/2)).put("p95DecodeLatencyMs",sorted.isEmpty()?-1:sorted.get(sorted.size()*95/100)).put("limitation","Synthetic video in the same Android emulator. Excludes physical capture, Wi-Fi and TV panel latency.");write(result.toString());
 }catch(Throwable e){try{write(new JSONObject().put("error",e.toString()).toString());}catch(Exception ignored){}}finally{if(sender!=null)sender.close();if(track!=null)track.dispose();if(at!=null)at.dispose();if(source!=null)source.dispose();if(as!=null)as.dispose();if(audio!=null)audio.release();if(egl!=null)egl.release();runOnUiThread(()->{if(receiver!=null){receiver.close();receiver=null;}finish();});}}
 private void write(String text)throws IOException{try(FileOutputStream out=openFileOutput("rtc-probe.json",MODE_PRIVATE)){out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}}
 @Override public void onDestroy(){stopped=true;super.onDestroy();}
}
