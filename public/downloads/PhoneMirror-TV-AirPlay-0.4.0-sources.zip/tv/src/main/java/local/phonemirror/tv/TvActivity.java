package local.phonemirror.tv;

import android.app.Activity;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.*;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;
import java.net.*;
import org.json.JSONObject;

@androidx.media3.common.util.UnstableApi
public final class TvActivity extends Activity implements TvControlServer.Listener {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TvControlServer server;
    private ExoPlayer player;
    private volatile RtcReceiver rtc;
    private PlayerView playerView;
    private FrameLayout root;
    private LinearLayout welcome;
    private TextView feedback;
    private volatile String state="waiting",error="";
    private volatile boolean rendered;
    private volatile long videoFrames,lastVideoFrameAt;
    private volatile long droppedFrames,videoPtsUs;
    private int liveRecoveries;
    private String ip="";
    @Override protected void onCreate(Bundle saved){super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
    @Override protected void onStart(){super.onStart();root=new FrameLayout(this);root.setBackgroundColor(0xff0c0e18);setContentView(root);ip=localIp();try{if(ip.isEmpty())throw new java.io.IOException("Connectez la TV au même réseau que votre téléphone.");server=new TvControlServer(ip,this);}catch(Exception e){error=e.getMessage();}showWelcome();}
    private String localIp(){ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);Network network=cm.getActiveNetwork();LinkProperties links=network==null?null:cm.getLinkProperties(network);if(links!=null)for(LinkAddress a:links.getLinkAddresses())if(a.getAddress() instanceof Inet4Address&&a.getAddress().isSiteLocalAddress())return a.getAddress().getHostAddress();return "";}
    private void showWelcome(){
        welcome=new LinearLayout(this);welcome.setOrientation(LinearLayout.VERTICAL);welcome.setGravity(Gravity.CENTER);welcome.setPadding(dp(40),dp(30),dp(40),dp(30));
        welcome.addView(text("PhoneMirror TV",36,0xfff2f0fa,true));space(welcome,10);welcome.addView(text("Votre téléphone. En grand. Sans navigateur.",17,0xffaaa3bc,false));space(welcome,26);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setPadding(dp(35),dp(20),dp(35),dp(22));GradientDrawable bg=new GradientDrawable();bg.setColor(0xff1c1b2e);bg.setCornerRadius(dp(20));bg.setStroke(dp(1),0xff403453);card.setBackground(bg);
        card.addView(text("DANS L'APPLICATION DU TÉLÉPHONE",11,0xffa99acb,true));space(card,12);card.addView(text("Choisissez PhoneMirror TV",18,0xfff2f0fa,true));space(card,17);card.addView(text("ADRESSE DE LA TV",10,0xff9992aa,false));space(card,7);card.addView(text(ip.isEmpty()?"Réseau indisponible":ip,27,0xffbca6ff,true));space(card,14);card.addView(text("CODE D'APPAIRAGE",10,0xff9992aa,false));space(card,6);TextView code=text(server==null?"------":server.pin,38,0xfff2f0fa,true);code.setLetterSpacing(.16f);card.addView(code);
        welcome.addView(card);space(welcome,15);Button airplay=new Button(this);airplay.setText("iPhone / iPad · Ouvrir AirPlay");airplay.setTextColor(0xfff2f0fa);airplay.setOnClickListener(v->startActivity(new Intent(this,AirPlayActivity.class)));welcome.addView(airplay);space(welcome,8);feedback=text(error.isEmpty()?"Même Wi-Fi ou réseau Ethernet · gardez cet écran ouvert":error,12,error.isEmpty()?0xff9699af:0xffffb1a5,false);welcome.addView(feedback);root.addView(welcome,new FrameLayout.LayoutParams(-1,-1));
    }
    @Override public void play(String url){main.post(()->startPlayer(url));}
    @Override public JSONObject rtcOffer(JSONObject offer)throws Exception{
        java.util.concurrent.CompletableFuture<RtcReceiver> ready=new java.util.concurrent.CompletableFuture<>();
        main.post(()->{try{String id=offer.getString("id");if(rtc==null||!rtc.id.equals(id)){releasePlayer();rendered=false;state="buffering";error="";welcome.setVisibility(View.GONE);rtc=new RtcReceiver(this,root,id);}ready.complete(rtc);}catch(Exception e){ready.completeExceptionally(e);}});
        return ready.get(4,java.util.concurrent.TimeUnit.SECONDS).answer(offer);
    }
    @Override public JSONObject rtcExchange(JSONObject request)throws Exception{RtcReceiver current=rtc;if(current==null||!current.id.equals(request.optString("id")))throw new IllegalArgumentException("Session WebRTC périmée");return current.exchange(request);}
    private void startPlayer(String url){
        releasePlayer();rendered=false;videoFrames=0;lastVideoFrameAt=0;droppedFrames=0;videoPtsUs=0;liveRecoveries=0;state="buffering";error="";welcome.setVisibility(View.GONE);
        playerView=new PlayerView(this);playerView.setUseController(true);playerView.setKeepScreenOn(true);root.addView(playerView,0,new FrameLayout.LayoutParams(-1,-1));
        DefaultLoadControl buffering=new DefaultLoadControl.Builder().setBufferDurationsMs(4000,15000,1000,3000).setPrioritizeTimeOverSizeThresholds(true).build();
        player=new ExoPlayer.Builder(this).setLoadControl(buffering).build();playerView.setPlayer(player);
        player.setVideoFrameMetadataListener((presentationTimeUs,releaseTimeNs,format,mediaFormat)->{videoFrames++;videoPtsUs=presentationTimeUs;lastVideoFrameAt=SystemClock.elapsedRealtime();});
        player.addAnalyticsListener(new androidx.media3.exoplayer.analytics.AnalyticsListener(){@Override public void onDroppedVideoFrames(EventTime eventTime,int count,long elapsedMs){droppedFrames+=count;}});
        player.addListener(new Player.Listener(){
            @Override public void onRenderedFirstFrame(){rendered=true;state="playing";}
            @Override public void onPlaybackStateChanged(int value){if(value==Player.STATE_BUFFERING)state="buffering";else if(value==Player.STATE_READY)state=rendered?"playing":"ready";else if(value==Player.STATE_ENDED){state="ended";stopPlayback();}}
            @Override public void onPlayerError(PlaybackException failure){if(failure.errorCode==PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW&&liveRecoveries++<3){state="buffering";player.seekToDefaultPosition();player.prepare();player.play();return;}state="error";error="Lecture interrompue ("+failure.getErrorCodeName()+"). Relancez le partage depuis le téléphone.";releasePlayer();welcome.setVisibility(View.VISIBLE);feedback.setText(error);}
        });
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(false).setConnectTimeoutMs(4000).setReadTimeoutMs(6000);
        MediaItem media=new MediaItem.Builder().setUri(url).setMimeType(MimeTypes.APPLICATION_M3U8).setLiveConfiguration(new MediaItem.LiveConfiguration.Builder().setTargetOffsetMs(5000).setMinPlaybackSpeed(.97f).setMaxPlaybackSpeed(1.03f).build()).build();
        player.setMediaSource(new HlsMediaSource.Factory(http).setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(5)).createMediaSource(media));player.prepare();player.play();
    }
    @Override public void stopPlayback(){main.post(()->{releasePlayer();state="waiting";rendered=false;if(welcome!=null)welcome.setVisibility(View.VISIBLE);});}
    @Override public JSONObject status(){JSONObject status=new JSONObject();try{RtcReceiver current=rtc;if(current!=null)return current.status();long last=lastVideoFrameAt;status.put("state",state).put("rendered",rendered).put("frames",videoFrames).put("videoPtsUs",videoPtsUs).put("droppedFrames",droppedFrames).put("lastFrameAgeMs",last==0?-1:SystemClock.elapsedRealtime()-last).put("error",error);}catch(Exception ignored){}return status;}
    private void releasePlayer(){RtcReceiver current=rtc;rtc=null;if(current!=null)current.close();if(playerView!=null){playerView.setPlayer(null);root.removeView(playerView);playerView=null;}if(player!=null){player.release();player=null;}}
    @Override protected void onStop(){if(server!=null){server.stop();server=null;}releasePlayer();main.removeCallbacksAndMessages(null);state="waiting";rendered=false;super.onStop();}
    @Override public void onBackPressed(){if(player!=null||rtc!=null)stopPlayback();else super.onBackPressed();}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void space(LinearLayout parent,int size){parent.addView(new View(this),new LinearLayout.LayoutParams(1,dp(size)));}
}
