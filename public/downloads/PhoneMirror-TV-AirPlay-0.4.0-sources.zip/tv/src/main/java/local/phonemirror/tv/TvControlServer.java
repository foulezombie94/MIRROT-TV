package local.phonemirror.tv;

import fi.iki.elonen.NanoHTTPD;

import org.json.JSONObject;

import java.io.*;

import java.net.*;

import java.nio.charset.StandardCharsets;

import java.security.*;

import java.util.*;

import java.util.concurrent.*;

/** A TV companion protocol, not a browser receiver. One locally paired controller. */

final class TvControlServer extends NanoHTTPD {

    interface Listener { void play(String url); void stopPlayback(); JSONObject status(); JSONObject rtcOffer(JSONObject offer)throws Exception; JSONObject rtcExchange(JSONObject request)throws Exception; }

    private final Listener listener;

    final String pin;

    private String token="",owner="";

    private final Map<String,long[]> attempts=new LinkedHashMap<>();

    private final ThreadPoolExecutor pool=new ThreadPoolExecutor(3,3,0,TimeUnit.SECONDS,new ArrayBlockingQueue<>(5));

    private final java.util.List<ClientHandler> active=Collections.synchronizedList(new ArrayList<>());

    TvControlServer(String ip,Listener listener)throws IOException {

        super(ip,17600);this.listener=listener;pin=String.format(Locale.US,"%06d",new SecureRandom().nextInt(1_000_000));

        setAsyncRunner(new AsyncRunner(){public void exec(ClientHandler handler){active.add(handler);try{pool.execute(handler);}catch(RejectedExecutionException busy){active.remove(handler);handler.close();}}public void closed(ClientHandler handler){active.remove(handler);}public void closeAll(){synchronized(active){for(ClientHandler h:active)h.close();active.clear();}pool.shutdownNow();}});

        start(3000,false);

    }

    @Override public synchronized Response serve(IHTTPSession session){

        try{

            if(session.getMethod()==Method.GET&&session.getUri().equals("/hello"))return json(Response.Status.OK,new JSONObject().put("app","PhoneMirror TV").put("protocol",2).put("webrtc",true));

            if(session.getMethod()!=Method.POST)return json(Response.Status.METHOD_NOT_ALLOWED,new JSONObject().put("error","POST requis"));

            int length=Integer.parseInt(session.getHeaders().getOrDefault("content-length","0"));

            int maximum=session.getUri().startsWith("/rtc/")?65536:2048;
            if(length<0||length>maximum||session.getHeaders().containsKey("transfer-encoding"))return error(Response.Status.BAD_REQUEST,"Requête invalide");

            byte[] bytes=new byte[length];int pos=0;while(pos<length){int n=session.getInputStream().read(bytes,pos,length-pos);if(n<0)throw new EOFException();pos+=n;}

            JSONObject data=new JSONObject(length==0?"{}":new String(bytes,StandardCharsets.UTF_8));String ip=session.getRemoteIpAddress();

            if(session.getUri().equals("/pair")){

                long now=System.nanoTime()/1_000_000;long[] a=attempts.get(ip);if(a==null||now-a[0]>60_000){a=new long[]{now,0};attempts.put(ip,a);}if(attempts.size()>32)attempts.remove(attempts.keySet().iterator().next());

                if(++a[1]>8)return error(Response.Status.FORBIDDEN,"Trop d'essais. Attendez une minute.");

                if(!MessageDigest.isEqual(pin.getBytes(StandardCharsets.UTF_8),data.optString("pin").getBytes(StandardCharsets.UTF_8)))return error(Response.Status.FORBIDDEN,"Code incorrect");

                if(!owner.isEmpty()&&!owner.equals(ip))return error(Response.Status.CONFLICT,"Un autre téléphone est connecté. Relancez le récepteur TV pour changer.");

                owner=ip;byte[] secret=new byte[24];new SecureRandom().nextBytes(secret);token=android.util.Base64.encodeToString(secret,android.util.Base64.NO_WRAP|android.util.Base64.URL_SAFE);

                return json(Response.Status.OK,new JSONObject().put("token",token).put("protocol",2).put("webrtc",true));

            }

            String auth=session.getHeaders().getOrDefault("authorization","");

            if(token.isEmpty()||!owner.equals(ip)||!MessageDigest.isEqual(("Bearer "+token).getBytes(StandardCharsets.UTF_8),auth.getBytes(StandardCharsets.UTF_8)))return error(Response.Status.FORBIDDEN,"Appairage nécessaire");

            switch(session.getUri()){
                case "/rtc/offer"->{if(!data.optString("id").matches("[a-f0-9-]{36}")||data.optString("sdp").length()>48000)return error(Response.Status.BAD_REQUEST,"Session WebRTC invalide");return json(Response.Status.OK,listener.rtcOffer(data));}
                case "/rtc/ice"->{return json(Response.Status.OK,listener.rtcExchange(data));}

                case "/play"->{URI uri=URI.create(data.getString("url"));if(!"http".equals(uri.getScheme())||!ip.equals(uri.getHost())||uri.getUserInfo()!=null||!uri.getPath().matches("/[a-f0-9]{36}/live\\.m3u8"))return error(Response.Status.BAD_REQUEST,"Source vidéo invalide");listener.play(uri.toString());return json(Response.Status.OK,new JSONObject().put("accepted",true));}

                case "/stop"->{listener.stopPlayback();return json(Response.Status.OK,new JSONObject().put("stopped",true));}

                case "/status"->{return json(Response.Status.OK,listener.status());}

                default->{return error(Response.Status.NOT_FOUND,"Commande inconnue");}

            }

        }catch(Exception invalid){return error(Response.Status.BAD_REQUEST,"Requête invalide");}

    }

    private Response error(Response.Status code,String message){try{return json(code,new JSONObject().put("error",message));}catch(Exception ignored){return newFixedLengthResponse(code,"application/json","{}");}}

    private Response json(Response.Status status,JSONObject json){Response r=newFixedLengthResponse(status,"application/json; charset=utf-8",json.toString());r.addHeader("Cache-Control","no-store");return r;}

}

