package local.phonemirror.tv;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.airtv.receiver.airplay.AirPlayReceiver;
import com.airtv.receiver.airplay.ReceiverState;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Unit;

/** Dedicated AirPlay screen: its native server and codecs never share a session with WebRTC. */
public final class AirPlayActivity extends Activity implements SurfaceHolder.Callback {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor(r->new Thread(r,"PhoneMirror-AirPlay"));
    private AirPlayReceiver receiver;
    private SurfaceView surface;
    private FrameLayout root;
    private LinearLayout instructions;
    private TextView status,detail;
    private volatile boolean active;
    private WifiManager.MulticastLock multicast;
    private ConnectivityManager networks;
    private Network currentNetwork;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Runnable restart=()->worker.execute(()->{stopReceiver();if(active)startReceiver();});

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);setContentView(root);
        surface=new SurfaceView(this);surface.getHolder().addCallback(this);
        root.addView(surface,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        root.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->fitPicture());
        instructions=new LinearLayout(this);instructions.setOrientation(LinearLayout.VERTICAL);
        instructions.setGravity(Gravity.CENTER);instructions.setPadding(dp(40),dp(24),dp(40),dp(24));
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff171528,0xff090d18});
        instructions.setBackground(background);
        instructions.addView(label("PhoneMirror · AirPlay",32,0xfff6f1ff,true));
        instructions.addView(label("Votre iPhone, directement sur la télévision",17,0xffb6b0c8,false));
        status=label("Préparation du récepteur…",23,0xffc7adff,true);pad(status,22);instructions.addView(status);
        detail=label("Même Wi-Fi · iPhone : Centre de contrôle → Recopie de l’écran",16,0xffded9eb,false);instructions.addView(detail);
        TextView back=label("Retour pour quitter AirPlay",12,0xffa3a0b0,false);pad(back,18);instructions.addView(back);
        root.addView(instructions,new FrameLayout.LayoutParams(-1,-1));
        try {
            receiver=new AirPlayReceiver(getApplicationContext());
            receiver.addListener(value->{if(active)update(value);return Unit.INSTANCE;});
        } catch(LinkageError | RuntimeException failure) {
            status.setText("AirPlay indisponible sur cet appareil");detail.setText(failure.getMessage());
        }
    }

    @Override protected void onStart() {
        super.onStart();active=true;
        if(receiver==null)return;
        worker.execute(this::startReceiver);
        networks=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        currentNetwork=networks.getActiveNetwork();
        networkCallback=new ConnectivityManager.NetworkCallback(){
            @Override public void onAvailable(Network network){networkChanged(network);}
            @Override public void onLost(Network network){if(Objects.equals(network,currentNetwork))networkChanged(null);}
        };
        networks.registerDefaultNetworkCallback(networkCallback);
    }
    private void networkChanged(Network next) {
        main.post(()->{if(!active||Objects.equals(next,currentNetwork))return;currentNetwork=next;
            main.removeCallbacks(restart);main.postDelayed(restart,1000);});
    }
    private void startReceiver() {
        if(!active||receiver==null)return;
        try {
            WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if(wifi!=null){multicast=wifi.createMulticastLock("PhoneMirror-AirPlay");multicast.setReferenceCounted(false);multicast.acquire();}
            if(!receiver.start())releaseMulticast();
        } catch(RuntimeException | LinkageError failure) {
            releaseMulticast();main.post(()->{if(active){instructions.setVisibility(View.VISIBLE);status.setText("Impossible de démarrer AirPlay");detail.setText(failure.getMessage());}});
        }
    }
    private void stopReceiver() {
        try{if(receiver!=null)receiver.stop();}catch(RuntimeException failure){android.util.Log.w("PhoneMirrorAirPlay","Arrêt du récepteur",failure);}
        finally{releaseMulticast();}
    }
    private void releaseMulticast(){if(multicast!=null){if(multicast.isHeld())multicast.release();multicast=null;}}
    private void update(ReceiverState value) {
        if(value instanceof ReceiverState.Streaming) {
            ReceiverState.Streaming stream=(ReceiverState.Streaming)value;
            if(stream.getWidth()>0&&stream.getHeight()>0){instructions.setVisibility(View.GONE);fitPicture();}
        } else if(value instanceof ReceiverState.Advertising) {
            ReceiverState.Advertising ready=(ReceiverState.Advertising)value;instructions.setVisibility(View.VISIBLE);
            status.setText("Choisissez « "+ready.getName()+" » sur l’iPhone");
            detail.setText("Centre de contrôle → Recopie de l’écran\nMême réseau Wi-Fi ou Ethernet");
        } else if(value instanceof ReceiverState.Failed) {
            instructions.setVisibility(View.VISIBLE);status.setText("Connexion AirPlay indisponible");detail.setText(((ReceiverState.Failed)value).getReason());
        } else if(value instanceof ReceiverState.AudioOnly) {
            ReceiverState.AudioOnly audio=(ReceiverState.AudioOnly)value;instructions.setVisibility(View.VISIBLE);
            status.setText(audio.getPlayable()?"Lecture audio AirPlay":"Ce format audio n’est pas pris en charge");
            detail.setText("Pour afficher l’écran : Centre de contrôle → Recopie de l’écran");
        }
    }
    private void fitPicture() {
        if(receiver==null||!(receiver.getState() instanceof ReceiverState.Streaming))return;
        ReceiverState.Streaming picture=(ReceiverState.Streaming)receiver.getState();
        if(picture.getWidth()<=0||picture.getHeight()<=0||root.getWidth()==0||root.getHeight()==0)return;
        double scale=Math.min((double)root.getWidth()/picture.getWidth(),(double)root.getHeight()/picture.getHeight());
        int w=Math.max(1,(int)Math.round(picture.getWidth()*scale)),h=Math.max(1,(int)Math.round(picture.getHeight()*scale));
        FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)surface.getLayoutParams();
        if(old.width!=w||old.height!=h)surface.setLayoutParams(new FrameLayout.LayoutParams(w,h,Gravity.CENTER));
    }
    @Override public void surfaceCreated(SurfaceHolder holder){if(receiver!=null)receiver.setSurface(holder.getSurface());}
    @Override public void surfaceChanged(SurfaceHolder holder,int format,int width,int height){if(receiver!=null)receiver.setSurface(holder.getSurface());}
    @Override public void surfaceDestroyed(SurfaceHolder holder){if(receiver!=null)receiver.setSurface(null);}
    @Override protected void onStop() {
        active=false;main.removeCallbacks(restart);
        if(networkCallback!=null){networks.unregisterNetworkCallback(networkCallback);networkCallback=null;}
        worker.execute(this::stopReceiver);super.onStop();
    }
    @Override protected void onDestroy(){worker.shutdown();super.onDestroy();}
    private TextView label(String text,int size,int color,boolean bold){TextView view=new TextView(this);view.setText(text);view.setTextSize(size);view.setTextColor(color);view.setGravity(Gravity.CENTER);view.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return view;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private void pad(View view,int vertical){view.setPadding(0,dp(vertical),0,dp(vertical));}
}
