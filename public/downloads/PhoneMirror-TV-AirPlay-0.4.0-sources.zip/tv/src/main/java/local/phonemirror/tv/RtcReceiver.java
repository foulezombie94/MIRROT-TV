package local.phonemirror.tv;

import android.content.Context;
import android.os.SystemClock;
import android.widget.FrameLayout;
import org.json.*;
import org.webrtc.*;
import org.webrtc.audio.JavaAudioDeviceModule;
import local.phonemirror.rtc.RtcPeer;

/** SurfaceViewRenderer presents decoded RTP video without an HLS/DASH media buffer. */
final class RtcReceiver implements AutoCloseable {
    final String id;
    private final EglBase egl=EglBase.create();
    private final SurfaceViewRenderer view;
    private final FrameLayout root;
    private final JavaAudioDeviceModule audio;
    private final RtcPeer peer;
    private VideoTrack video;
    private volatile long frames,lastFrameAt,firstFrameAt;
    private volatile boolean rendered;
    private long lastStats;
    RtcReceiver(Context context,FrameLayout root,String id){this(context,root,id,null);}
    RtcReceiver(Context context,FrameLayout root,String id,VideoSink observed){
        this.root=root;this.id=id;RtcPeer.initialize(context);
        view=new SurfaceViewRenderer(context);view.init(egl.getEglBaseContext(),new RendererCommon.RendererEvents(){public void onFirstFrameRendered(){rendered=true;firstFrameAt=SystemClock.elapsedRealtime();}public void onFrameResolutionChanged(int w,int h,int r){}});view.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);view.setEnableHardwareScaler(true);root.addView(view,0,new FrameLayout.LayoutParams(-1,-1));
        audio=JavaAudioDeviceModule.builder(context).setUseLowLatency(true).setUseStereoOutput(true).setEnableVolumeLogger(false).setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MOVIE).build()).createAudioDeviceModule();audio.setAudioRecordEnabled(false);
        peer=new RtcPeer(context,egl.getEglBaseContext(),audio,new RtcPeer.Listener(){@Override public void video(VideoTrack track){video=track;track.addSink(frame->{frames++;lastFrameAt=SystemClock.elapsedRealtime();if(observed!=null)observed.onFrame(frame);});track.addSink(view);}});
    }
    synchronized JSONObject answer(JSONObject offer)throws Exception{return new JSONObject().put("id",id).put("sdp",peer.answer(offer.getString("sdp"))).put("candidates",peer.ice());}
    synchronized JSONObject exchange(JSONObject request)throws Exception{peer.addIce(request.optJSONArray("candidates"));long now=SystemClock.elapsedRealtime();if(now-lastStats>=1000){lastStats=now;peer.collectStats();}return new JSONObject().put("candidates",peer.ice()).put("status",status());}
    synchronized JSONObject status()throws JSONException{return new JSONObject().put("state",rendered&&"connected".equals(peer.connection)?"playing":peer.connection).put("rendered",rendered).put("frames",frames).put("lastFrameAgeMs",lastFrameAt==0?-1:SystemClock.elapsedRealtime()-lastFrameAt).put("firstFrameAt",firstFrameAt).put("transport","webrtc").put("metrics",peer.metrics());}
    @Override public synchronized void close(){peer.close();view.release();root.removeView(view);audio.release();egl.release();}
}
